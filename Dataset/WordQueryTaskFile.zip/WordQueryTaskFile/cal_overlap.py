import numpy as np

if __name__ == '__main__':
    train_file = np.load('./train_task_file.npz')
    test_file = np.load('./test_task_file.npz')
    train_embedding = train_file['embeddings']
    test_embedding = test_file['embeddings']
    train_counts = train_file['counts']
    train_queries = train_file['queries']
    embedding_dic = {}
    for i in range((train_embedding.shape[0])):
        embedding = train_embedding[i]
        count = train_counts[i]
    # for embedding in train_embedding:
        if embedding.tobytes() in embedding_dic.keys():
            print(embedding)
            print(count)
            print(embedding_dic[embedding.tobytes()])
        # assert embedding.tobytes() not in embedding_dic.keys()
        embedding_dic[embedding.tobytes()] = count
    overlap_num = 0
    for embedding in test_embedding:
        if embedding.tobytes() in embedding_dic.keys():
            overlap_num += 1
    print(overlap_num)
    print(train_embedding.shape[0])
    print(test_embedding.shape[0])

    print('1')
##
## overlap num 33243
## train num 115646
## test num 115387